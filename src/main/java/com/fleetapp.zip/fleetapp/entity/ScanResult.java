package com.fleetapp.entity;

import java.util.List;

public class ScanResult {
    private String vehicleId;
    private List<String> detectedParameters;

    // Getters and Setters
    public String getVehicleId() { return vehicleId; }
    public void setVehicleId(String vehicleId) { this.vehicleId = vehicleId; }

    public List<String> getDetectedParameters() { return detectedParameters; }
    public void setDetectedParameters(List<String> detectedParameters) { this.detectedParameters = detectedParameters; }
}