package com.fleetapp.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fleetapp.config.GroundStationProcessManager;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyEmitter;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@RestController
@RequestMapping("/api/discovery")
@CrossOrigin(origins = "*")
public class DiscoveryController {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @GetMapping("/adapters")
    public ResponseEntity<List<String>> getAdapters() {
        try {
            Path adapterDir = Paths.get(System.getProperty("user.dir"), "Python_Files", "Python_Codes", "Vehicle_Adapters");
            List<String> adapters = new ArrayList<>();
            if (Files.exists(adapterDir)) {
                try (var stream = Files.list(adapterDir)) {
                    stream.filter(Files::isRegularFile)
                            .map(p -> p.getFileName().toString())
                            .filter(name -> name.endsWith(".py") && !name.startsWith("."))
                            .forEach(adapters::add);
                }
            }
            return ResponseEntity.ok(adapters);
        } catch (Exception e) {
            return ResponseEntity.ok(Collections.emptyList());
        }
    }

    @GetMapping("/configs")
    public ResponseEntity<List<Map<String, Object>>> getConfigs() {
        try {
            Path path = Paths.get(System.getProperty("user.dir"), "vehicle_configs.json");
            if (Files.exists(path)) {
                List<Map<String, Object>> configs = objectMapper.readValue(path.toFile(), new TypeReference<List<Map<String, Object>>>() {});
                return ResponseEntity.ok(configs);
            }
            return ResponseEntity.ok(Collections.emptyList());
        } catch (Exception e) {
            return ResponseEntity.ok(Collections.emptyList());
        }
    }

    @PostMapping("/configs")
    public ResponseEntity<?> saveVehicleConfig(@RequestBody Map<String, Object> payload) {
        try {
            Path path = Paths.get(System.getProperty("user.dir"), "vehicle_configs.json");
            List<Map<String, Object>> configs = new ArrayList<>();

            if (Files.exists(path)) {
                configs = objectMapper.readValue(path.toFile(), new TypeReference<List<Map<String, Object>>>() {});
            }

            String vehicleId = (String) payload.get("id");
            configs.removeIf(c -> vehicleId != null && vehicleId.equals(c.get("id")));
            configs.add(payload);

            objectMapper.writerWithDefaultPrettyPrinter().writeValue(path.toFile(), configs);
            return ResponseEntity.ok(Map.of("status", "success"));

        } catch (Exception e) {
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping(value = "/scan", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseBodyEmitter scanSpectrum(@RequestBody Map<String, String> request) {
        ResponseBodyEmitter emitter = new ResponseBodyEmitter(60000L);

        new Thread(() -> {
            try {
                emitter.send(">> Querying in-memory background telemetry cache...\n");
                Thread.sleep(800);

                Map<String, Set<String>> cache = GroundStationProcessManager.getDiscoveredCache();

                emitter.send(">> Intercepted active entities: " + cache.size() + "\n");
                Thread.sleep(400);
                emitter.send("---SCAN_COMPLETE---\n");

                List<Map<String, Object>> results = new ArrayList<>();
                for (Map.Entry<String, Set<String>> entry : cache.entrySet()) {
                    Map<String, Object> vehicleInfo = new HashMap<>();
                    vehicleInfo.put("vehicleId", entry.getKey());
                    vehicleInfo.put("detectedParameters", new ArrayList<>(entry.getValue()));
                    results.add(vehicleInfo);
                }

                emitter.send(objectMapper.writeValueAsString(results) + "\n");
                emitter.complete();

            } catch (Exception e) {
                try {
                    emitter.send(">> ERROR during scan: " + e.getMessage() + "\n");
                    emitter.completeWithError(e);
                } catch (Exception ignored) {}
            }
        }).start();

        return emitter;
    }
}