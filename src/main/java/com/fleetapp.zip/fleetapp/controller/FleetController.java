package com.fleetapp.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fleetapp.entity.ControlSchema;
import com.fleetapp.entity.Vehicle;
import com.fleetapp.service.FleetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/fleet")
@CrossOrigin(origins = "*")
public class FleetController {

    private static final Logger logger = LoggerFactory.getLogger(FleetController.class);

    private final FleetService fleetService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public FleetController(FleetService fleetService) {
        this.fleetService = fleetService;
    }

    @GetMapping("/vehicles")
    public ResponseEntity<List<Vehicle>> getVehicles() {
        return ResponseEntity.ok(fleetService.getAllVehicles());
    }

    @GetMapping("/schemas")
    public ResponseEntity<List<ControlSchema>> getSchemas() {
        return ResponseEntity.ok(fleetService.getAllSchemas());
    }

    @PostMapping("/vehicles")
    public ResponseEntity<?> registerVehicle(@RequestBody String rawBody) {
        try {
            JsonNode jsonNode = objectMapper.readTree(rawBody);

            String rawId = jsonNode.has("id") ? jsonNode.get("id").asText() : null;
            String name = jsonNode.has("name") ? jsonNode.get("name").asText() : null;
            String category = jsonNode.has("category") ? jsonNode.get("category").asText() : null;

            if (rawId == null || rawId.isBlank()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Vehicle ID is required"));
            }

            UUID vehicleUuid;
            try {
                vehicleUuid = UUID.fromString(rawId);
            } catch (IllegalArgumentException e) {
                vehicleUuid = UUID.nameUUIDFromBytes(rawId.getBytes());
            }

            String vehicleName = (name != null && !name.isBlank()) ? name : rawId;
            String safeCategory = (category != null && !category.isBlank()) ? category.toUpperCase() : "UAV";
            if (safeCategory.length() > 20) {
                safeCategory = safeCategory.substring(0, 20);
            }

            // Execute a pure JDBC atomic Upsert - completely bypasses Hibernate entity tracking and locking
            jdbcTemplate.update(
                    "INSERT INTO vehicles (id, name, category) VALUES (?, ?, ?) " +
                            "ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, category = EXCLUDED.category",
                    vehicleUuid, vehicleName, safeCategory
            );

            logger.info("Successfully registered vehicle via JDBC Upsert: {} ({})", vehicleName, vehicleUuid);
            return ResponseEntity.ok(Map.of("status", "success", "uuid", vehicleUuid.toString()));

        } catch (Exception e) {
            logger.error("Failed to register vehicle", e);
            return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/vehicles/{id}/history")
    public ResponseEntity<?> getVehicleHistory(@PathVariable("id") String id) {
        return ResponseEntity.ok(fleetService.getVehicleHistory(id));
    }
}