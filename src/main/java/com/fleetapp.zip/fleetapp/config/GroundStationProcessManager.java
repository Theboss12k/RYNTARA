package com.fleetapp.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fleetapp.repository.VehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.data.geo.Point;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import jakarta.annotation.PreDestroy;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

@Component
public class GroundStationProcessManager {

    private static final Logger logger = LoggerFactory.getLogger(GroundStationProcessManager.class);

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Autowired
    private VehicleRepository vehicleRepository;

    private final List<Process> activePythonProcesses = new ArrayList<>();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final ExecutorService streamExecutor = Executors.newCachedThreadPool();

    // IN-MEMORY DISCOVERY CACHE (Option B)
    private static final Map<String, Set<String>> discoveredCache = new ConcurrentHashMap<>();

    public static Map<String, Set<String>> getDiscoveredCache() {
        return discoveredCache;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void startAllAdapters() {
        logger.info("Initializing Ground Station Adapters...");

        Path adapterDir = Paths.get(System.getProperty("user.dir"), "Python_Files", "Python_Codes", "Vehicle_Adapters");

        if (!Files.exists(adapterDir)) {
            logger.warn("Adapter directory not found: {}", adapterDir);
            return;
        }

        // Dynamically find and launch every Python adapter in the folder
        try (Stream<Path> paths = Files.list(adapterDir)) {
            paths.filter(Files::isRegularFile)
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .filter(name -> name.endsWith(".py") && !name.startsWith("."))
                    .forEach(this::launchAdapterProcess);
        } catch (IOException e) {
            logger.error("Failed to read adapter directory", e);
        }
    }

    private void launchAdapterProcess(String scriptName) {
        try {
            Path scriptPath = Paths.get(System.getProperty("user.dir"), "Python_Files", "Python_Codes", "Vehicle_Adapters", scriptName);

            ProcessBuilder processBuilder = new ProcessBuilder(
                    "Python_Files/.venv/bin/python3.13",
                    scriptPath.toString(),
                    "--listen-ip", "0.0.0.0"
            );

            processBuilder.redirectErrorStream(true);
            processBuilder.environment().put("PYTHONUNBUFFERED", "1");

            Process process = processBuilder.start();
            activePythonProcesses.add(process);

            logger.info("Launched adapter '{}' successfully with PID: {}", scriptName, process.pid());
            startStreamProcessor(process, scriptName);

        } catch (IOException e) {
            logger.error("Failed to start adapter script: {}", scriptName, e);
        }
    }

    private void startStreamProcessor(Process process, String scriptName) {
        streamExecutor.submit(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {

                    if (!line.trim().startsWith("{")) {
                        logger.debug("[{}] {}", scriptName, line);
                        continue;
                    }

                    try {
                        JsonNode payload = objectMapper.readTree(line);

                        // Extract vehicle ID across multiple property name conventions
                        String vehicleId = null;
                        if (payload.has("vehicle_id")) {
                            vehicleId = payload.get("vehicle_id").asText();
                        } else if (payload.has("uav_id")) {
                            vehicleId = payload.get("uav_id").asText();
                        } else if (payload.has("craft_id")) {
                            vehicleId = payload.get("craft_id").asText();
                        }

                        // 1. POPULATE OPTION B DISCOVERY CACHE IN REAL-TIME
                        if (vehicleId != null && !vehicleId.isBlank()) {
                            Set<String> keys = new HashSet<>();
                            payload.fieldNames().forEachRemaining(keys::add);
                            discoveredCache.computeIfAbsent(vehicleId, k -> new HashSet<>()).addAll(keys);
                        }

                        // 2. FIREWALL & REDIS PIPELINE
                        if (vehicleId != null && isVehicleAuthorized(vehicleId)) {
                            // Publish to Redis Pub/Sub for WebSockets / Live Map
                            redisTemplate.convertAndSend("telemetry.live", line);

                            // Update Redis GeoSpatial cache
                            if (payload.has("longitude") && payload.has("latitude")) {
                                double lon = payload.get("longitude").asDouble();
                                double lat = payload.get("latitude").asDouble();
                                redisTemplate.opsForGeo().add("fleet_locations", new Point(lon, lat), vehicleId);
                            }
                        } else {
                            logger.warn("[{}] Firewall Blocked Unauthorized ID: {}", scriptName, vehicleId);
                        }

                    } catch (Exception e) {
                        logger.error("[{}] Failed to parse incoming JSON: {}", scriptName, line, e);
                    }
                }
            } catch (IOException e) {
                logger.error("[{}] Error reading adapter stream", scriptName, e);
            }
        });
    }

    private boolean isVehicleAuthorized(String vehicleIdStr) {
        if (vehicleIdStr == null || vehicleIdStr.isBlank()) {
            return false;
        }

        try {
            java.nio.file.Path configPath = java.nio.file.Paths.get(System.getProperty("user.dir"), "vehicle_configs.json");
            if (java.nio.file.Files.exists(configPath)) {
                com.fasterxml.jackson.databind.JsonNode root = objectMapper.readTree(configPath.toFile());
                if (root.isArray()) {
                    for (com.fasterxml.jackson.databind.JsonNode node : root) {
                        if (node.has("id") && vehicleIdStr.equals(node.get("id").asText())) {
                            return true; // Authorized!
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error reading vehicle_configs.json", e);
        }

        return false;
    }

    @PreDestroy
    public void stopAllAdapters() {
        logger.info("Shutting down all Ground Station Python adapters...");
        for (Process process : activePythonProcesses) {
            if (process.isAlive()) {
                process.destroy();
            }
        }
        streamExecutor.shutdownNow();
    }
}