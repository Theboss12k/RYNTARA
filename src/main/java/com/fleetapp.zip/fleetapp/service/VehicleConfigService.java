package com.fleetapp.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fleetapp.entity.ScanResult;
import com.fleetapp.entity.VehicleConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class VehicleConfigService {

    private static final Logger logger = LoggerFactory.getLogger(VehicleConfigService.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    private final String ADAPTERS_DIR = "Python_Files/Python_Codes/Vehicle_Adapters";
    private final String CONFIG_FILE = "vehicle_configs.json";

    public List<String> getAvailableAdapters() {
        File folder = new File(ADAPTERS_DIR);
        List<String> adapters = new ArrayList<>();

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.endsWith("_adapter.py"));
            if (files != null) {
                for (File file : files) {
                    adapters.add(file.getName());
                }
            }
        } else {
            logger.warn("Adapter directory not found: {}", ADAPTERS_DIR);
            // Create the directory for future use if it doesn't exist
            folder.mkdirs();
        }
        return adapters;
    }

    public void streamScanForVehicles(String adapterName, java.io.OutputStream out) throws Exception {
        String scriptPath = ADAPTERS_DIR + "/" + adapterName;

        // Ensure the -u flag is present so Python output is unbuffered
        ProcessBuilder processBuilder = new ProcessBuilder("Python_Files/.venv/bin/python3.13", "-u", scriptPath, "--scan");
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.write((line + "\n").getBytes());
                out.flush();
            }
        }

        process.waitFor(12, TimeUnit.SECONDS);

        // CRITICAL FIX: If Python crashes, explicitly notify the frontend
        if (process.exitValue() != 0) {
            out.write(("CRITICAL ERROR: Python script exited prematurely with code " + process.exitValue() + "\n").getBytes());
            out.flush();
        }
    }

    public List<VehicleConfig> getAllConfigs() {
        File file = new File(CONFIG_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        try {
            return objectMapper.readValue(file, new TypeReference<List<VehicleConfig>>() {});
        } catch (IOException e) {
            logger.error("Error reading configs", e);
            return new ArrayList<>();
        }
    }

    public void saveConfig(VehicleConfig newConfig) {
        List<VehicleConfig> configs = getAllConfigs();

        // Remove existing config if it exists (update scenario)
        configs = configs.stream()
                .filter(c -> !c.getId().equals(newConfig.getId()))
                .collect(Collectors.toList());

        configs.add(newConfig);

        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(CONFIG_FILE), configs);
        } catch (IOException e) {
            logger.error("Error saving config", e);
            throw new RuntimeException("Failed to save vehicle configuration.");
        }
    }
}